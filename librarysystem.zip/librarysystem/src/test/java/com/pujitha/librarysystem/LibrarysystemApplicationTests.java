package com.pujitha.librarysystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LibrarysystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
